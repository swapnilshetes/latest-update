package com.electrolux.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.electrolux.pom.base.AppBase;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class AppHomepageObject extends AppBase {
	protected AndroidDriver driver;
	public AppHomepageObject(AndroidDriver<WebElement>pagedriver) {
		this.driver = driver;
	}
	
	public void navigateToLoginPage(){
		System.out.println("Tis is on navigation");
		WebDriverWait wait = new WebDriverWait(this.driver, 30);
		WebElement continueButton = wait.until(ExpectedConditions
				.visibilityOfElementLocated((MobileBy.xpath("//android.view.View[@content-desc=\"CONTINUE\"]"))));
		continueButton.click();
		return;
	}

}
