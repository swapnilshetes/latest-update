package com.electrolux.pom;

public class AppLoginPageObject {

}
