package com.electrolux.pom.base;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.electrolux.pom.AppHomepageObject;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class AppBase {

	protected  AppiumDriver<MobileElement> driver;
	AppHomepageObject appHomepage;

	

	public AppiumDriver<MobileElement> getDriver() {
		System.out.println(">>>>"+this.driver);
		return this.driver;
	}

	public void setDriver(AppiumDriver<MobileElement> driver) {
		System.out.println("<<<"+this.driver);
		this.driver = driver;
	}

}
