/**
 * 
 */
package com.indecomm.api;


import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterClass;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class AppiumDriverContext {
	//public static IOSDriverContext driverContext;
	//public static AppiumDriver<WebElement> driver;  
	public AppiumDriver<MobileElement> driver;
	
	public AppiumDriverContext()
	{
		
		//driver = this.deviceSetUp();
	}

	@Parameters({"device","apppackage","activity","version","appiumServer"})
	@BeforeClass
	public void deviceSetUp(String device, String apppackage, String activity, String version, String appiumServer) throws InterruptedException, MalformedURLException, InterruptedException
		{
			
			System.out.println("*****************************************************");
			System.out.println("Setting up device and desired capabilities");		
			
			DesiredCapabilities cap = DesiredCapabilities.android();
			cap.setCapability(MobileCapabilityType.DEVICE_NAME,device);	
			cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
			cap.setCapability(MobileCapabilityType.APP, "C:\\swapnil\\apk\\app-debug.apk");
	    	cap.setCapability(MobileCapabilityType.PLATFORM_NAME,Platform.ANDROID);
			cap.setCapability(MobileCapabilityType.BROWSER_NAME,BrowserType.ANDROID);
			cap.setCapability(MobileCapabilityType.VERSION,version);
/*			cap.setCapability(MobileCapabilityType.NO_RESET,"true");
			cap.setCapability(MobileCapabilityType.FULL_RESET,"false");*/

			URL url= new URL(appiumServer);
			driver = new AndroidDriver<MobileElement>(url,cap);	
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
/*			driver.closeApp();
			driver.installApp(appPath);
			driver.launchApp();
			driver.resetApp();*/
			
		}
	
	@Test
	public void LoginOnAndroid()
	{
		
		
		
	}
	
	
	
	
	@AfterClass
	public void closeDriver()
	{
		if(null != driver)
		{
			//driver.resetApp();
		driver.closeApp();
		driver.launchApp();
		//driver = null;
		}
	}	

}