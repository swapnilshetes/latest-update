package com.indecomm.scripts.el;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.indecomm.api.AppiumDriverContext;
import com.electrolux.pom.*;
import com.electrolux.pom.base.AppBase;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class LoginTestAnrdroid extends AppBase {
	AndroidDriver driver;
	AppHomepageObject appHomepage ;
	
	@Parameters({ "device", "app_package", "activity", "version", "appiumServer" })
	@BeforeTest(alwaysRun = true)
	public void deviceSetUp(String device, String app_package, String activity, String version, String appiumServer)
			throws InterruptedException, MalformedURLException, InterruptedException {

		DesiredCapabilities cap = DesiredCapabilities.android();
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, device);
		cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 120);
		cap.setCapability(MobileCapabilityType.APP, "D:\\appium-cucumber\\javatest-master\\test.apk");
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME, Platform.ANDROID);
		cap.setCapability(MobileCapabilityType.BROWSER_NAME, BrowserType.ANDROID);
		cap.setCapability(MobileCapabilityType.VERSION, version);
		System.out.println("This is what");
		URL url = new URL(appiumServer);
		driver = new AndroidDriver<MobileElement>(url, cap);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		appHomepage = new AppHomepageObject(driver);
}
	

	@Given("^Customer is on the App Homepage on Android Device$")
	public void user_is_on_Home_Page() throws Throwable {
		//driver = AppBase.driver;
		System.out.println("Test 1");
		appHomepage.navigateToLoginPage();
		
	}

	@When("^Customer Navigates to the  Log in Page$")
	public void user_Navigate_to_LogIn_Page() throws Throwable {
		
		
	}

	@When("^Enters Username and Password in the login fields$")
	public void user_enters_UserName_and_Password() throws Throwable {
		WebElement username = driver.findElementByXPath("//*[@class='android.widget.EditText'][1]");
		username.sendKeys("electrolux.test2018@gmail.com");
		WebElement password = driver.findElementByXPath("//*[@class='android.widget.EditText'][2]");
		password.sendKeys("Indecomm@123");
		WebElement login = driver.findElementByXPath("//android.view.View[@content-desc=\"LOG IN\"]");
		login.click();

		// WebDriverWait wait = new WebDriverWait(driver,1);
		// WebElement login =
		// wait.until(ExpectedConditions.visibilityOfElementLocated((MobileBy.xpath("//android.view.View[@text='LOG
		// IN']"))));
		// login.click();

		Thread.sleep(3000);
		// Write code here that turns the phrase above into concrete actions
		// throw new PendingException();
	}

	@Then("^Successful login message is displayed on the dashboard page$")
	public void message_displayed_Login_Successfully() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		// throw new PendingException();
	}
}
